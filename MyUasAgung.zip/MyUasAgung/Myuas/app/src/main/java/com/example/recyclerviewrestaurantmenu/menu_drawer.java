package com.example.recyclerviewrestaurantmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class menu_drawer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_drawer);
    }
}