package com.example.recyclerviewrestaurantmenu;

public interface OnItemClickCallback {
    void onItemClicked(Food food);
}
