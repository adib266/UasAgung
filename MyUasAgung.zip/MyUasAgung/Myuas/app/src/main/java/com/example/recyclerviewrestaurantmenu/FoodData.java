package com.example.recyclerviewrestaurantmenu;


import java.util.ArrayList;

public class FoodData {
    private static String [] foodName = {
            "Sate Kambing",
            "Milkshake",
            "pancake",
            "Onion Rings",
            "Chicken Dominator",
            "Chicken Lover",
            "Extra Vaganzza",
            "Beff Burger",


    };

    private static String [] foodDetail = {
            "Sate kambing muda , daging sumper empuk dan wenak",
            "Milkshake , menyegarkan dahaga",
            "pancake super flufy and cremy",
            "onion rings sangat krispy ",
            "Rustic Sauce, Green Paprika, Corn, Chili Chicken, Chicken Pepperoni",
            "Tomato Sauce, Chicken Rasher, parsley, Chicken Pepperoni, Marinated Chicken, Cheesy Bites, Mozzarella Cheese",
            "Domino's Pizza Sauce, Green Pepper, Onion, Black Olives, Mushroom, Beef",
            "Beff Burger exstra keju",

    };
    private static String [] foodPrice = {
            "Rp. 70,000",
            "Rp. 20,000",
            "Rp. 50,000",
            "Rp. 135,000",
            "Rp. 200,000",
            "Rp. 78,000",
            "Rp. 99,000",
            "Rp. 69,000",



    };
    private static int[] foodImage = {
            R.drawable.sate,
            R.drawable.milkshake,
            R.drawable.pancake,
            R.drawable.cheesemania,
            R.drawable.chickendominator,
            R.drawable.chickenlover,
            R.drawable.extravaganzza,
            R.drawable.burger



    };

    static ArrayList<Food> getListData(){
        ArrayList<Food> list = new ArrayList<>();
        for (int position = 0; position <foodName.length; position++) {
            Food food = new Food();
            food.setName(foodName[position]);
            food.setPrice(foodPrice[position]);
            food.setDetail(foodDetail[position]);
            food.setPhoto(foodImage[position]);
            list.add(food);
        }
        return list;
    }
}